<script>
    window.mediaPicker = window.mediaPicker || {
        setPreview: function (inputId, url) {
            const input = document.getElementById(inputId);
            if (!input) return;

            const picker = input.closest('[data-media-picker]');
            if (!picker) return;

            const container = picker.querySelector('[data-media-preview-container]');
            const preview = picker.querySelector('[data-media-preview]');
            const label = picker.querySelector('[data-media-label]');
            const removeField = picker.querySelector('[data-media-remove-field]');

            input.value = '';
            if (removeField) removeField.value = '0';
            if (label) label.textContent = input.dataset.chooseLabel || label.textContent;

            if (url) {
                preview.src = url;
                container.classList.remove('d-none');
            } else {
                preview.removeAttribute('src');
                container.classList.add('d-none');
            }
        },

        reset: function (scope) {
            $(scope || document).find('[data-media-picker]').each(function () {
                const picker = this;
                const input = picker.querySelector('[data-media-input]');
                const container = picker.querySelector('[data-media-preview-container]');
                const preview = picker.querySelector('[data-media-preview]');
                const label = picker.querySelector('[data-media-label]');
                const removeField = picker.querySelector('[data-media-remove-field]');

                if (input) input.value = '';
                if (removeField) removeField.value = '0';
                if (preview) preview.removeAttribute('src');
                if (container) container.classList.add('d-none');
                if (label) label.textContent = input?.dataset.chooseLabel || 'Choose image file...';
            });
        }
    };

    $(document).on('change', '[data-media-input]', function () {
        const input = this;
        const picker = input.closest('[data-media-picker]');
        const file = input.files && input.files[0];
        if (!picker || !file) return;

        const label = picker.querySelector('[data-media-label]');
        const preview = picker.querySelector('[data-media-preview]');
        const container = picker.querySelector('[data-media-preview-container]');
        const removeField = picker.querySelector('[data-media-remove-field]');

        if (label) label.textContent = file.name;
        if (removeField) removeField.value = '0';
        if (preview) preview.src = URL.createObjectURL(file);
        if (container) container.classList.remove('d-none');
    });

    $(document).on('click', '[data-media-remove]', function () {
        const picker = this.closest('[data-media-picker]');
        if (!picker) return;

        const input = picker.querySelector('[data-media-input]');
        const label = picker.querySelector('[data-media-label]');
        const container = picker.querySelector('[data-media-preview-container]');
        const preview = picker.querySelector('[data-media-preview]');
        const removeField = picker.querySelector('[data-media-remove-field]');

        if (input) input.value = '';
        if (label) label.textContent = input?.dataset.chooseLabel || 'Choose image file...';
        if (preview) preview.removeAttribute('src');
        if (container) container.classList.add('d-none');
        if (removeField) removeField.value = '1';
    });
</script>
