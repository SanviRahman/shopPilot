@props([
    'name',
    'inputId',
    'label' => 'Image',
    'chooseLabel' => 'Choose image file...',
    'removeName' => null,
    'previewUrl' => null,
])

@php
    $removeName = $removeName ?: 'remove_' . $name;
    $previewId = $inputId . '-preview';
    $previewContainerId = $inputId . '-preview-container';
@endphp

<div class="media-picker" data-media-picker>
    <label for="{{ $inputId }}" class="font-weight-600">{{ $label }}</label>
    <div class="custom-file mb-2">
        <input
            type="file"
            class="custom-file-input"
            id="{{ $inputId }}"
            name="{{ $name }}"
            accept="image/*"
            data-media-input
            data-choose-label="{{ $chooseLabel }}"
        >
        <label class="custom-file-label custom-file-label-sm" for="{{ $inputId }}" data-media-label>
            {{ $chooseLabel }}
        </label>
    </div>

    <input type="hidden" name="{{ $removeName }}" value="0" data-media-remove-field>

    <div
        id="{{ $previewContainerId }}"
        class="media-picker-preview mt-2 {{ $previewUrl ? '' : 'd-none' }}"
        data-media-preview-container
    >
        <div class="d-inline-flex align-items-start border rounded p-1 bg-light">
            <img
                id="{{ $previewId }}"
                src="{{ $previewUrl ?: '' }}"
                alt="{{ $label }} preview"
                class="img-thumbnail border-0"
                style="max-height: 100px; max-width: 180px; object-fit: cover;"
                data-media-preview
            >
            <button
                type="button"
                class="btn btn-sm btn-outline-danger ml-1"
                title="Remove image"
                data-media-remove
            >
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
</div>
