<?php if(!empty($standalone)): ?>
    
    <?php $__env->startSection('meta_title', 'Admin Details'); ?>
    <?php $__env->startSection('page_content'); ?>
        <div class="card card-outline card-info">
            <div class="card-header"><h3 class="card-title">Admin Details</h3></div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-3">Name</dt><dd class="col-sm-9"><?php echo e($admin->name); ?></dd>
                    <dt class="col-sm-3">Email</dt><dd class="col-sm-9"><?php echo e($admin->email); ?></dd>
                    <dt class="col-sm-3">Status</dt><dd class="col-sm-9"><?php echo e(ucfirst($admin->status)); ?></dd>
                    <dt class="col-sm-3">Roles</dt><dd class="col-sm-9"><?php echo e($admin->roles->pluck('name')->join(', ') ?: 'No role'); ?></dd>
                    <dt class="col-sm-3">Created At</dt><dd class="col-sm-9"><?php echo e(optional($admin->created_at)->format('d M Y, h:i A')); ?></dd>
                </dl>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php else: ?>
    <div class="modal fade" id="showAdminModal<?php echo e($admin->id); ?>" tabindex="-1" role="dialog" aria-labelledby="showAdminModalLabel<?php echo e($admin->id); ?>" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="showAdminModalLabel<?php echo e($admin->id); ?>"><i class="fas fa-user mr-1"></i>Admin Details</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <dl class="row mb-0">
                        <dt class="col-sm-4">Name</dt><dd class="col-sm-8"><?php echo e($admin->name); ?></dd>
                        <dt class="col-sm-4">Email</dt><dd class="col-sm-8"><?php echo e($admin->email); ?></dd>
                        <dt class="col-sm-4">Status</dt><dd class="col-sm-8"><?php echo e(ucfirst($admin->status)); ?></dd>
                        <dt class="col-sm-4">Roles</dt><dd class="col-sm-8"><?php echo e($admin->roles->pluck('name')->join(', ') ?: 'No role'); ?></dd>
                        <dt class="col-sm-4">Created</dt><dd class="col-sm-8"><?php echo e(optional($admin->created_at)->format('d M Y, h:i A')); ?></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/admins/partials/show.blade.php ENDPATH**/ ?>