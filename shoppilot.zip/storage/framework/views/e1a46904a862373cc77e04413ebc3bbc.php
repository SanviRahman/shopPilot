<?php
    $isEdit = $mode === 'edit' && $admin;
    $action = $isEdit ? route('admin.admins.update', $admin) : route('admin.admins.store');
?>

<div class="modal fade" id="adminFormModal" tabindex="-1" role="dialog" aria-labelledby="adminFormModalLabel" aria-hidden="true" data-open-form="<?php echo e($openForm ? 'true' : 'false'); ?>">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form action="<?php echo e($action); ?>" method="POST" autocomplete="off">
                <?php echo csrf_field(); ?>
                <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="adminFormModalLabel">
                        <i class="fas fa-user-shield mr-1"></i><?php echo e($isEdit ? 'Update Admin' : 'Create Admin'); ?>

                    </h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="admin-name">Name <span class="text-danger">*</span></label>
                            <input type="text" id="admin-name" name="name" value="<?php echo e(old('name', $admin?->name)); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="admin-email">Email <span class="text-danger">*</span></label>
                            <input type="email" id="admin-email" name="email" value="<?php echo e(old('email', $admin?->email)); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="admin-password">Password <?php if (! ($isEdit)): ?><span class="text-danger">*</span><?php endif; ?></label>
                            <input type="password" id="admin-password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php echo e($isEdit ? '' : 'required'); ?>>
                            <?php if($isEdit): ?><small class="form-text text-muted">Leave blank to keep the current password.</small><?php endif; ?>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="admin-password-confirmation">Confirm Password <?php if (! ($isEdit)): ?><span class="text-danger">*</span><?php endif; ?></label>
                            <input type="password" id="admin-password-confirmation" name="password_confirmation" class="form-control" <?php echo e($isEdit ? '' : 'required'); ?>>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="admin-status">Status <span class="text-danger">*</span></label>
                            <select id="admin-status" name="status" class="form-control" required>
                                <?php $__currentLoopData = ['active', 'inactive']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>" <?php if(old('status', $admin?->status ?? 'active') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-12">
                            <label>Admin Roles <span class="text-danger">*</span></label>
                            <div class="row border rounded p-2 ml-0 mr-0">
                                <?php ($selectedRoles = old('roles', $admin?->roles?->modelKeys() ?? [])); ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 custom-control custom-checkbox mb-2">
                                        <input type="checkbox" class="custom-control-input" id="role-<?php echo e($role->id); ?>" name="roles[]" value="<?php echo e($role->id); ?>" <?php if(in_array($role->id, $selectedRoles)): echo 'checked'; endif; ?>>
                                        <label class="custom-control-label" for="role-<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger small"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['roles.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger small"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i>Save Admin</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\shoppilot\resources\views/backoffice/admin/admins/partials/form.blade.php ENDPATH**/ ?>