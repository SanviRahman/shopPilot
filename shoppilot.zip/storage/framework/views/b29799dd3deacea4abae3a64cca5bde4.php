<?php ($isTrash = $isTrash ?? false); ?>

<div class="table-responsive">
    <table id="<?php echo e($isTrash ? 'trash-list' : 'admins-list'); ?>" class="table table-hover table-bordered mb-0">
        <thead class="thead-light">
            <tr>
                <th width="40"><input type="checkbox" data-select-all="#<?php echo e($isTrash ? 'trash-list' : 'admins-list'); ?>"></th>
                <th>Name</th>
                <th>Email</th>
                <th>Roles</th>
                <?php if($isTrash): ?>
                    <th>Deleted At</th>
                <?php else: ?>
                    <th>Status</th>
                <?php endif; ?>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><input type="checkbox" name="admin_ids[]" value="<?php echo e($admin->id); ?>" data-row-checkbox></td>
                    <td class="font-weight-bold">
                        <?php echo e($admin->name); ?>

                        <?php if(! $isTrash && auth('admin')->id() === $admin->id): ?>
                            <span class="badge badge-danger ml-1">You</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($admin->email); ?></td>
                    <td>
                        <?php $__empty_2 = true; $__currentLoopData = $admin->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <span class="badge badge-info mr-1"><?php echo e(strtoupper($role->name)); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <span class="text-muted">No role</span>
                        <?php endif; ?>
                    </td>
                    <?php if($isTrash): ?>
                        <td><?php echo e(optional($admin->deleted_at)->format('d M Y, h:i A')); ?></td>
                    <?php else: ?>
                        <td><span class="badge badge-<?php echo e($admin->isActive() ? 'success' : 'secondary'); ?>"><?php echo e(ucfirst($admin->status)); ?></span></td>
                    <?php endif; ?>
                    <td class="text-right text-nowrap">
                        <?php if($isTrash): ?>
                            <?php if(auth('admin')->user()?->can('staff.restore')): ?>
                                <form action="<?php echo e(route('admin.admins.restore', $admin->id)); ?>" method="POST" class="d-inline" data-confirm="Restore this admin?">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-outline-success btn-sm" title="Restore"><i class="fas fa-trash-restore"></i></button>
                                </form>
                            <?php endif; ?>
                            <?php if(auth('admin')->user()?->can('staff.force-delete')): ?>
                                <form action="<?php echo e(route('admin.admins.force-delete', $admin->id)); ?>" method="POST" class="d-inline" data-confirm="Permanently delete this admin? This cannot be undone.">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger btn-sm" title="Permanent Delete"><i class="fas fa-times"></i></button>
                                </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if(auth('admin')->user()?->can('staff.view')): ?>
                                <button type="button" class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#showAdminModal<?php echo e($admin->id); ?>" title="View"><i class="fas fa-eye"></i></button>
                            <?php endif; ?>
                            <?php if(auth('admin')->user()?->can('staff.update')): ?>
                                <a href="<?php echo e(route('admin.admins.edit', $admin)); ?>" class="btn btn-outline-primary btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
                            <?php endif; ?>
                            <?php if(auth('admin')->user()?->can('staff.delete') && auth('admin')->id() !== $admin->id && ! $admin->isSuperAdmin()): ?>
                                <form action="<?php echo e(route('admin.admins.destroy', $admin)); ?>" method="POST" class="d-inline" data-confirm="Move this admin to trash?">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php if(! $isTrash): ?>
                    <?php echo $__env->make('backoffice.admin.admins.partials.show', ['admin' => $admin], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4"><?php echo e($isTrash ? 'Trash is empty.' : 'No admin users found.'); ?></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\shoppilot\resources\views/backoffice/admin/admins/partials/table.blade.php ENDPATH**/ ?>