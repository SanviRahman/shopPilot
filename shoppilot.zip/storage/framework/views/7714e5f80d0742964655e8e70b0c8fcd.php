<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH D:\shoppilot\resources\views/vendor/adminlte/partials/footer/footer.blade.php ENDPATH**/ ?>