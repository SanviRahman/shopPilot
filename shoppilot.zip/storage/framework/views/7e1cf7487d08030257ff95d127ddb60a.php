<?php
    $isEdit = $mode === 'edit' && $role;
    $action = $isEdit ? route('admin.roles.update', $role) : route('admin.roles.store');
    $selectedPermissions = old('permissions', $role?->permissions?->modelKeys() ?? []);
    $permissionGroups = $permissions->groupBy(fn ($permission) => $permission->group_name ?: 'Other');
?>
<div class="modal fade" id="roleFormModal" tabindex="-1" role="dialog" aria-hidden="true" data-open-form="<?php echo e($openForm ? 'true' : 'false'); ?>">
    <div class="modal-dialog modal-lg" role="document"><div class="modal-content">
        <form action="<?php echo e($action); ?>" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?> <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <div class="modal-header bg-primary text-white"><h5 class="modal-title"><i class="fas fa-user-tag mr-1"></i><?php echo e($isEdit ? 'Update Role' : 'Create Role'); ?></h5><button type="button" class="close text-white" data-dismiss="modal"><span>&times;</span></button></div>
            <div class="modal-body">
                <div class="form-group"><label for="role-name">Role Name <span class="text-danger">*</span></label><input id="role-name" name="name" value="<?php echo e(old('name', $role?->name)); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. manager" required><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                <div class="form-group"><label>Permissions</label><div class="border rounded p-3" style="max-height:360px;overflow:auto;">
                    <?php $__currentLoopData = $permissionGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupPermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3"><strong class="text-primary"><?php echo e($group); ?></strong><div class="row mt-2">
                            <?php $__currentLoopData = $groupPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 custom-control custom-checkbox mb-2"><input type="checkbox" class="custom-control-input" id="role-permission-<?php echo e($permission->id); ?>" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php if(in_array($permission->id, $selectedPermissions)): echo 'checked'; endif; ?>><label class="custom-control-label" for="role-permission-<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger small"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button><button class="btn btn-primary"><i class="fas fa-save mr-1"></i>Save Role</button></div>
        </form>
    </div></div>
</div>
<?php /**PATH D:\shoppilot\resources\views/backoffice/admin/roles/partials/form.blade.php ENDPATH**/ ?>