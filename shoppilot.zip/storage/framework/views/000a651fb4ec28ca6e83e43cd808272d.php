

<?php $__env->startSection('title'); ?>
    <?php if (! empty(trim($__env->yieldContent('meta_title')))): ?>
        <?php echo $__env->yieldContent('meta_title'); ?> |
    <?php endif; ?>
    <?php echo e(config('adminlte.title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_tags'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if(isset($title) || isset($breadcrumb)): ?>
        <div class="container-fluid">
            <div class="row mb-1 align-items-center">
                <div class="col-md-6 col-12 text-center text-md-left">
                    <?php if(isset($title)): ?>
                        <h1 class="m-0 text-dark font-weight-bold">
                            <i class="fas fa-layer-group text-primary mr-2"></i><?php echo e($title); ?>

                            <?php if(isset($sub_title)): ?>
                                <small class="text-muted font-weight-light ml-md-2"><?php echo e($sub_title); ?></small>
                            <?php endif; ?>
                        </h1>
                    <?php endif; ?>
                </div>

                <div class="col-md-6 col-12 mt-3 mt-md-0">
                    <?php if(isset($breadcrumb) && count($breadcrumb)): ?>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb float-md-right shadow-sm border-0 px-3 py-2 bg-white rounded-pill">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('admin.redirect')); ?>" class="text-primary">
                                        <i class="fas fa-home"></i>
                                    </a>
                                </li>

                                <?php $__currentLoopData = $breadcrumb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($crumb['url']) && $crumb['url']): ?>
                                        <li class="breadcrumb-item">
                                            <a href="<?php echo e($crumb['url']); ?>" class="text-muted font-weight-bold"><?php echo e($crumb['text']); ?></a>
                                        </li>
                                    <?php else: ?>
                                        <li class="breadcrumb-item active text-secondary" aria-current="page"><?php echo e($crumb['text']); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldContent('page_content'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('backoffice.admin.includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('backoffice.admin.includes.custom_js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <?php echo $__env->make('backoffice.admin.includes.custom_css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shoppilot\resources\views/layouts/admin.blade.php ENDPATH**/ ?>