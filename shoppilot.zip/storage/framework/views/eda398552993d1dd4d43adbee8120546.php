

<?php $__env->startSection('meta_title', 'Admin Users'); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle mr-1"></i><?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Please fix the following:</strong>
            <ul class="mb-0 mt-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
    <?php endif; ?>

    <div class="d-flex flex-wrap align-items-center mb-3">
        <a href="<?php echo e(route('admin.admins.create')); ?>" class="btn btn-primary mr-2 mb-2">
            <i class="fas fa-plus mr-1"></i>Add New Admin
        </a>
        <a href="<?php echo e(route('admin.admins.trash')); ?>" class="btn btn-outline-danger mr-2 mb-2">
            <i class="fas fa-trash mr-1"></i>Trash Bin
        </a>

        <form action="<?php echo e(route('admin.admins.bulk-action')); ?>" method="POST" class="form-inline mb-2" data-confirm-bulk>
            <?php echo csrf_field(); ?>
            <select name="action" class="form-control mr-2" required>
                <option value="">-- Bulk Actions --</option>
                <?php if(auth('admin')->user()?->can('staff.delete')): ?><option value="delete">Move to Trash</option><?php endif; ?>
                <?php if(auth('admin')->user()?->can('staff.restore')): ?><option value="restore">Restore</option><?php endif; ?>
                <?php if(auth('admin')->user()?->can('staff.force-delete')): ?><option value="force-delete">Permanent Delete</option><?php endif; ?>
            </select>
            <button type="submit" class="btn btn-secondary">Apply</button>
        </form>
    </div>

    <div class="card card-outline card-primary">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-users mr-1"></i>Admin Users List</h3>
        </div>
        <div class="card-body border-bottom">
            <form method="GET" action="<?php echo e(route('admin.admins.index')); ?>" class="row">
                <div class="form-group col-md-3 mb-2">
                    <label for="role_id">Filter by Role</label>
                    <select name="role_id" id="role_id" class="form-control">
                        <option value="">All Roles</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php if((string) request('role_id') === (string) $role->id): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-md-6 mb-2">
                    <label for="search">Search Admins</label>
                    <input type="search" name="search" id="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Search by name or email...">
                </div>
                <div class="form-group col-md-3 mb-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary mr-2"><i class="fas fa-search mr-1"></i>Search</button>
                    <a href="<?php echo e(route('admin.admins.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>

        <?php echo $__env->make('backoffice.admin.admins.partials.table', ['isTrash' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if($admins->hasPages()): ?>
            <div class="card-footer"><?php echo e($admins->links()); ?></div>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('backoffice.admin.admins.partials.form', [
        'admin' => $formAdmin,
        'roles' => $roles,
        'mode' => $formMode,
        'openForm' => $openForm,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('backoffice.admin.admins.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/admins/index.blade.php ENDPATH**/ ?>