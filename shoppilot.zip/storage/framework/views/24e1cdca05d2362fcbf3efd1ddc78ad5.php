<div class="float-right">
    Version: <?php echo e(config('app.version', '1.0.0')); ?>

</div>

<strong>
    <a href="<?php echo e(config('app.company_url', 'https://sfashanto.netlify.app/')); ?>">
        <?php echo e(config('app.company_name', 'SFA Shanto')); ?>

    </a>
</strong><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/includes/footer.blade.php ENDPATH**/ ?>