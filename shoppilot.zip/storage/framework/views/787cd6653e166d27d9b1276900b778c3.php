<script>
    window.addEventListener('load', function () {
        // Ecommerce admin custom JavaScript goes here.
    });
</script><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/includes/custom_js.blade.php ENDPATH**/ ?>