

<?php $__env->startSection('meta_title', 'Admin Dashboard'); ?>

<?php $__env->startSection('page_content'); ?>
    <div class="card">
        <div class="card-body">
            Welcome, <?php echo e(auth()->user()->name); ?>.
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/dashboard.blade.php ENDPATH**/ ?>