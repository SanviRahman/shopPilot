<?php ($isTrash = $isTrash ?? false); ?>
<div class="table-responsive">
    <table id="<?php echo e($isTrash ? 'trash-roles-list' : 'roles-list'); ?>" class="table table-hover table-bordered mb-0">
        <thead class="thead-light">
            <tr>
                <th width="40"><input type="checkbox" data-select-all="#<?php echo e($isTrash ? 'trash-roles-list' : 'roles-list'); ?>"></th>
                <th>Role Name</th><th>Guard Name</th><th>Permissions Count</th><th>Users Count</th>
                <?php if($isTrash): ?><th>Deleted At</th><?php endif; ?>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><input type="checkbox" name="role_ids[]" value="<?php echo e($role->id); ?>" data-row-checkbox></td>
                    <td class="font-weight-bold">
                        <i class="fas fa-shield-alt text-primary mr-1"></i><?php echo e($role->name); ?>

                        <?php if($role->isProtected()): ?><span class="badge badge-danger ml-1">Protected</span><?php endif; ?>
                    </td>
                    <td><span class="badge badge-secondary"><?php echo e(strtoupper($role->guard_name)); ?></span></td>
                    <td><span class="badge badge-info"><?php echo e($role->permissions_count ?? $role->permissions->count()); ?></span></td>
                    <td><span class="badge badge-success"><?php echo e($role->admins_count ?? 0); ?></span></td>
                    <?php if($isTrash): ?><td><?php echo e(optional($role->deleted_at)->format('d M Y, h:i A')); ?></td><?php endif; ?>
                    <td class="text-right text-nowrap">
                        <?php if($isTrash): ?>
                            <?php if(auth('admin')->user()?->can('roles.manage')): ?>
                                <form action="<?php echo e(route('admin.roles.restore', $role->id)); ?>" method="POST" class="d-inline" data-confirm="Restore this role?"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-outline-success btn-sm" title="Restore"><i class="fas fa-trash-restore"></i></button></form>
                                <?php if (! ($role->isProtected())): ?>
                                    <form action="<?php echo e(route('admin.roles.force-delete', $role->id)); ?>" method="POST" class="d-inline" data-confirm="Permanently delete this role?"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-outline-danger btn-sm" title="Permanent Delete"><i class="fas fa-times"></i></button></form>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if(auth('admin')->user()?->can('roles.view')): ?><button type="button" class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#showRoleModal<?php echo e($role->id); ?>"><i class="fas fa-eye"></i></button><?php endif; ?>
                            <?php if(auth('admin')->user()?->can('roles.manage')): ?><a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-edit"></i></a><?php endif; ?>
                            <?php if(auth('admin')->user()?->can('roles.manage') && ! $role->isProtected()): ?><form action="<?php echo e(route('admin.roles.destroy', $role)); ?>" method="POST" class="d-inline" data-confirm="Move this role to trash?"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-outline-danger btn-sm"><i class="fas fa-trash"></i></button></form><?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php if(! $isTrash): ?> <?php echo $__env->make('backoffice.admin.roles.partials.show', ['role' => $role], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="<?php echo e($isTrash ? 7 : 6); ?>" class="text-center text-muted py-4"><?php echo e($isTrash ? 'Trash is empty.' : 'No roles found.'); ?></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\shoppilot\resources\views/backoffice/admin/roles/partials/table.blade.php ENDPATH**/ ?>