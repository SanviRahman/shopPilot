<style>
    .content-header .breadcrumb {
        margin-bottom: 0;
    }
</style><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/includes/custom_css.blade.php ENDPATH**/ ?>