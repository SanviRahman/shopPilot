

<?php $__env->startSection('meta_title', 'Permissions'); ?>

<?php $__env->startSection('page_content'); ?>
    <?php echo $__env->make('backoffice.admin.permissions.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="d-flex flex-wrap align-items-center mb-3">
        <a href="<?php echo e(route('admin.permissions.create')); ?>" class="btn btn-primary mr-2 mb-2"><i class="fas fa-plus mr-1"></i>Add New Permission</a>
        <a href="<?php echo e(route('admin.permissions.trash')); ?>" class="btn btn-outline-danger mr-2 mb-2"><i class="fas fa-trash mr-1"></i>Trash Bin</a>
        <form action="<?php echo e(route('admin.permissions.bulk-action')); ?>" method="POST" class="form-inline mb-2" data-confirm-permission-bulk>
            <?php echo csrf_field(); ?>
            <select name="action" class="form-control mr-2" required>
                <option value="">-- Bulk Actions --</option>
                <?php if(auth('admin')->user()?->can('permissions.manage')): ?><option value="delete">Move to Trash</option><option value="restore">Restore</option><option value="force-delete">Permanent Delete</option><?php endif; ?>
            </select>
            <button type="submit" class="btn btn-secondary">Apply</button>
        </form>
    </div>

    <div class="card card-outline card-primary">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-key mr-1"></i>Permission List</h3></div>
        <div class="card-body border-bottom">
            <form method="GET" action="<?php echo e(route('admin.permissions.index')); ?>" class="row">
                <div class="form-group col-md-3 mb-2"><label for="permission-group">Group Name</label><select name="group_name" id="permission-group" class="form-control"><option value="">All Groups</option><?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($group); ?>" <?php if(request('group_name') === $group): echo 'selected'; endif; ?>><?php echo e($group); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="form-group col-md-6 mb-2"><label for="permission-search">Search Permissions</label><input type="search" name="search" id="permission-search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Search permission name..."></div>
                <div class="form-group col-md-3 mb-2 d-flex align-items-end"><button class="btn btn-primary mr-2"><i class="fas fa-search mr-1"></i>Search</button><a href="<?php echo e(route('admin.permissions.index')); ?>" class="btn btn-outline-secondary">Reset</a></div>
            </form>
        </div>

        <?php echo $__env->make('backoffice.admin.permissions.partials.table', ['isTrash' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if($permissions->hasPages()): ?><div class="card-footer"><?php echo e($permissions->links()); ?></div><?php endif; ?>
    </div>

    <?php echo $__env->make('backoffice.admin.permissions.partials.form', ['permission' => $formPermission, 'groups' => $groups, 'mode' => $formMode, 'openForm' => $openForm], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('backoffice.admin.permissions.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/permissions/index.blade.php ENDPATH**/ ?>