

<?php $__env->startSection('meta_title', 'Roles'); ?>

<?php $__env->startSection('page_content'); ?>
    <?php echo $__env->make('backoffice.admin.roles.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="d-flex flex-wrap align-items-center mb-3">
        <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-primary mr-2 mb-2"><i class="fas fa-plus mr-1"></i>Add New Role</a>
        <a href="<?php echo e(route('admin.roles.trash')); ?>" class="btn btn-outline-danger mr-2 mb-2"><i class="fas fa-trash mr-1"></i>Trash Bin</a>
        <form action="<?php echo e(route('admin.roles.bulk-action')); ?>" method="POST" class="form-inline mb-2" data-confirm-role-bulk>
            <?php echo csrf_field(); ?>
            <select name="action" class="form-control mr-2" required>
                <option value="">-- Bulk Actions --</option>
                <?php if(auth('admin')->user()?->can('roles.manage')): ?>
                    <option value="delete">Move to Trash</option>
                    <option value="restore">Restore</option>
                    <option value="force-delete">Permanent Delete</option>
                <?php endif; ?>
            </select>
            <button type="submit" class="btn btn-secondary">Apply</button>
        </form>
    </div>

    <div class="card card-outline card-primary">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-user-tag mr-1"></i>Roles List</h3></div>
        <div class="card-body border-bottom">
            <form method="GET" action="<?php echo e(route('admin.roles.index')); ?>" class="form-inline">
                <label for="role-search" class="mr-2">Search Roles</label>
                <input type="search" name="search" id="role-search" value="<?php echo e(request('search')); ?>" class="form-control mr-2" placeholder="Search role name...">
                <button type="submit" class="btn btn-primary mr-2"><i class="fas fa-search"></i></button>
                <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-outline-secondary">Reset</a>
            </form>
        </div>

        <?php echo $__env->make('backoffice.admin.roles.partials.table', ['isTrash' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if($roles->hasPages()): ?><div class="card-footer"><?php echo e($roles->links()); ?></div><?php endif; ?>
    </div>

    <?php echo $__env->make('backoffice.admin.roles.partials.form', [
        'role' => $formRole,
        'permissions' => $permissions,
        'mode' => $formMode,
        'openForm' => $openForm,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('backoffice.admin.roles.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shoppilot\resources\views/backoffice/admin/roles/index.blade.php ENDPATH**/ ?>