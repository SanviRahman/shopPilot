<?php
    $isEdit = $mode === 'edit' && $permission;
    $action = $isEdit ? route('admin.permissions.update', $permission) : route('admin.permissions.store');
?>
<div class="modal fade" id="permissionFormModal" tabindex="-1" role="dialog" aria-hidden="true" data-open-form="<?php echo e($openForm ? 'true' : 'false'); ?>"><div class="modal-dialog" role="document"><div class="modal-content">
    <form action="<?php echo e($action); ?>" method="POST" autocomplete="off">
        <?php echo csrf_field(); ?> <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <div class="modal-header bg-primary text-white"><h5 class="modal-title"><i class="fas fa-key mr-1"></i><?php echo e($isEdit ? 'Update Permission' : 'Create Permission'); ?></h5><button type="button" class="close text-white" data-dismiss="modal"><span>&times;</span></button></div>
        <div class="modal-body">
            <div class="form-group"><label for="permission-name">Permission Name <span class="text-danger">*</span></label><input id="permission-name" name="name" value="<?php echo e(old('name', $permission?->name)); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. products.view" required><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="form-group"><label for="permission-group-name">Group Name</label><input id="permission-group-name" name="group_name" value="<?php echo e(old('group_name', $permission?->group_name)); ?>" class="form-control" placeholder="e.g. Products"></div>
            <div class="form-group"><label for="permission-guard">Guard Name</label><input id="permission-guard" name="guard_name" value="admin" class="form-control" readonly></div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button><button class="btn btn-primary"><i class="fas fa-save mr-1"></i>Save Permission</button></div>
    </form>
</div></div></div>
<?php /**PATH D:\shoppilot\resources\views/backoffice/admin/permissions/partials/form.blade.php ENDPATH**/ ?>